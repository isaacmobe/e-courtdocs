<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to E-CourtDocs</title>
    <!-- Link to your main CSS file in the public/css/ folder -->
    <link rel="stylesheet" href="/e-courtdocsP4/public/css/style.css">
    <!-- Website system favicon -->
    <link rel="shortcut icon" href="/e-courtdocsP4/public/img/ecdfavicon.png" type="image/x-icon">
</head>
<body>

<!-- Simple Navigation for the Landing Page -->
<nav class="landing-nav">
    <div class="navbar-brand">
        <!-- Since index.php is in the same folder, just link to itself -->
        <a href="index.php">E-CourtDocs</a>
    </div>
    <div class="landing-menu">
        <!-- The links below should work because login.php and register.php 
             are also in the same directory as index.php -->
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <h1>Welcome to E-CourtDocs</h1>
        <p>Simplifying court case document management for everyone.</p>
        <div class="hero-buttons">
            <!-- Again, login.php and register.php are in the same folder -->
            <a href="login.php" class="btn-primary">Login</a>
            <a href="register.php" class="btn-secondary">Register</a>
        </div>
    </div>
</section>

<!-- About Us Section -->
<section class="about-section">
    <h2>About Us</h2>
    <p>
        E-CourtDocs is an innovative platform dedicated to streamlining the management of 
        court case documents. Our mission is to make it easier for lawyers, clients, and 
        administrative staff to securely manage, review, and track all necessary legal documents.
    </p>
</section>

<!-- Features Section -->
<section class="features-section">
    <h2>Key Features</h2>
    <ul>
        <li>Secure Login &amp; Registration</li>
        <li>Comprehensive Case Management</li>
        <li>Document Uploads &amp; Downloads</li>
        <li>Appointment Scheduling</li>
        <li>Real-time Notifications</li>
        <li>Admin Analytics &amp; User Management</li>
    </ul>
</section>

<!-- Landing Page Footer -->
<footer class="landing-footer">
    <p>&copy; <?php echo date('Y'); ?> E-CourtDocs. All rights reserved.</p>
</footer>

</body>
</html>
