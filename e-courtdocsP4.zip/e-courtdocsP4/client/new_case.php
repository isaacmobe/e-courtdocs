<?php
// client/new_case.php
require_once __DIR__ . '/../includes/header.php';

// Only clients can access
if (getUserRole() !== 'Client') {
    redirectToDashboard(getUserRole());
}

$message = "";

// Fetch all lawyers to display in a dropdown
$lawyerStmt = $pdo->query("SELECT userID, name FROM Users WHERE role='Lawyer'");
$lawyers = $lawyerStmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $caseNumber  = trim($_POST['case_number']);
    $title       = trim($_POST['title']);
    $status      = 'Filed'; // default status
    $assignedTo  = (int)$_POST['assigned_to'];
    $filingDate  = date('Y-m-d H:i:s');
    $lastUpdated = $filingDate;
    $clientID    = $_SESSION['userID'];

    // Insert case, now including clientID
    $insertCase = $pdo->prepare("
        INSERT INTO Cases
          (case_number, title, status, assigned_to, filing_date, last_updated, clientID)
        VALUES
          (:cnum, :title, :status, :assigned, :fdate, :lupdate, :clientID)
    ");
    $insertCase->execute([
        ':cnum'      => $caseNumber,
        ':title'     => $title,
        ':status'    => $status,
        ':assigned'  => $assignedTo,
        ':fdate'     => $filingDate,
        ':lupdate'   => $lastUpdated,
        ':clientID'  => $clientID
    ]);
    $newCaseID = $pdo->lastInsertId();

    // Handle optional document upload
    if (!empty($_FILES['case_document']['name'])) {
        $docTitle   = basename($_FILES['case_document']['name']);
        $docType    = pathinfo($docTitle, PATHINFO_EXTENSION);
        $docStatus  = 'Submitted';
        $uploadDate = date('Y-m-d H:i:s');

        // Ensure uploads directory exists
        $targetDir = __DIR__ . "/../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $targetFile = $targetDir . $docTitle;
        move_uploaded_file($_FILES['case_document']['tmp_name'], $targetFile);

        // Insert into Documents table
        $docStmt = $pdo->prepare("
            INSERT INTO Documents
              (caseID, uploaderID, title, type, status, upload_date)
            VALUES
              (:caseID, :uploaderID, :title, :type, :status, :udate)
        ");
        $docStmt->execute([
            ':caseID'     => $newCaseID,
            ':uploaderID' => $clientID,
            ':title'      => $docTitle,
            ':type'       => $docType,
            ':status'     => $docStatus,
            ':udate'      => $uploadDate
        ]);
    }

    // Notify the assigned lawyer
    createNotification(
        $pdo,
        $assignedTo,
        $newCaseID,
        "A new case (#{$caseNumber}) has been submitted by " . $_SESSION['name'],
        "New Case"
    );

    $message = "Case submitted successfully!";
}
?>

<h2>Submit New Case</h2>
<p><?php echo htmlspecialchars($message); ?></p>

<form method="POST" action="" enctype="multipart/form-data">
    <label for="case_number">Case Number</label>
    <input type="text" name="case_number" id="case_number" required>

    <label for="title">Case Title/Description</label>
    <input type="text" name="title" id="title" required>

    <label for="assigned_to">Assign Lawyer</label>
    <select name="assigned_to" id="assigned_to" required>
        <option value="">--Select Lawyer--</option>
        <?php foreach ($lawyers as $lawyer): ?>
            <option value="<?php echo $lawyer['userID']; ?>">
                <?php echo htmlspecialchars($lawyer['name']); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="case_document">Upload Document (Optional)</label>
    <input type="file" name="case_document" id="case_document">

    <button type="submit">Submit Case</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
