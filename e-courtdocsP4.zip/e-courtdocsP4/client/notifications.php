<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Client') {
    redirectToDashboard(getUserRole());
}

// Fetch notifications for this user
$userID = $_SESSION['userID'];
$notifications = getNotifications($pdo, $userID);

// Mark a notification as read if clicked
if (isset($_GET['read'])) {
    markNotificationAsRead($pdo, $_GET['read']);
    header("Location: notifications.php");
    exit;
}
?>

<h2>Your Notifications</h2>

<table>
    <tr>
        <th>Message</th>
        <th>Type</th>
        <th>Date</th>
        <th>Read?</th>
    </tr>
    <?php foreach($notifications as $note): ?>
    <tr>
        <td><?php echo $note['message']; ?></td>
        <td><?php echo $note['type']; ?></td>
        <td><?php echo $note['created_at']; ?></td>
        <td>
            <?php if($note['is_read']): ?>
                <span>Read</span>
            <?php else: ?>
                <a href="?read=<?php echo $note['notificationID']; ?>">Mark as Read</a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
