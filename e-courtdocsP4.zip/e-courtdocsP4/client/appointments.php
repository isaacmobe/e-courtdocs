<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Client') {
    redirectToDashboard(getUserRole());
}

$message = "";

// Fetch appointments for this client
$userID = $_SESSION['userID'];
$aptStmt = $pdo->prepare("SELECT Appointments.*, Cases.case_number 
                          FROM Appointments 
                          LEFT JOIN Cases ON Appointments.caseID = Cases.caseID
                          WHERE Appointments.userID = :uid
                          ORDER BY date_time DESC");
$aptStmt->execute([':uid' => $userID]);
$appointments = $aptStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch cases to link appointments to
$casesStmt = $pdo->prepare("SELECT * FROM Cases WHERE assigned_to IS NOT NULL");
$casesStmt->execute();
$allCases = $casesStmt->fetchAll(PDO::FETCH_ASSOC);

// Handle new appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_appointment'])) {
    $selectedCaseID = $_POST['caseID'];
    $dateTime       = $_POST['date_time'];
    $purpose        = $_POST['purpose'];
    $status         = 'Scheduled';

    $insApt = $pdo->prepare("INSERT INTO Appointments 
        (caseID, userID, date_time, purpose, status) 
        VALUES (:cid, :uid, :dt, :purp, :stat)");
    $insApt->execute([
        ':cid'  => $selectedCaseID,
        ':uid'  => $userID,
        ':dt'   => $dateTime,
        ':purp' => $purpose,
        ':stat' => $status
    ]);

    // Notify the lawyer associated with that case
    // First fetch the assigned_to from the Cases table
    $lawyerIDStmt = $pdo->prepare("SELECT assigned_to FROM Cases WHERE caseID = :cid");
    $lawyerIDStmt->execute([':cid' => $selectedCaseID]);
    $assignedToRow = $lawyerIDStmt->fetch(PDO::FETCH_ASSOC);
    $lawyerID = $assignedToRow ? $assignedToRow['assigned_to'] : null;

    if ($lawyerID) {
        createNotification($pdo, $lawyerID, $selectedCaseID, 
            "A new appointment has been scheduled by the client.", "Appointment");
    }

    $message = "Appointment scheduled successfully!";
    // Refresh the page
    header("Location: appointments.php");
    exit;
}
?>

<h2>Appointments</h2>
<p><?php echo $message; ?></p>

<!-- List of existing appointments -->
<h3>Your Appointments</h3>
<table>
    <tr>
        <th>Case #</th>
        <th>Date & Time</th>
        <th>Purpose</th>
        <th>Status</th>
    </tr>
    <?php foreach($appointments as $apt): ?>
    <tr>
        <td><?php echo $apt['case_number']; ?></td>
        <td><?php echo $apt['date_time']; ?></td>
        <td><?php echo $apt['purpose']; ?></td>
        <td><?php echo $apt['status']; ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<!-- Form to schedule a new appointment -->
<h3>Schedule New Appointment</h3>
<form method="POST" action="">
    <input type="hidden" name="new_appointment" value="1">
    <label for="caseID">Select Case</label>
    <select name="caseID" id="caseID" required>
        <option value="">--Select Case--</option>
        <?php foreach($allCases as $c): ?>
            <option value="<?php echo $c['caseID']; ?>">
                <?php echo $c['case_number'] . " - " . $c['title']; ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="date_time">Date & Time</label>
    <input type="datetime-local" name="date_time" id="date_time" required>

    <label for="purpose">Purpose</label>
    <textarea name="purpose" id="purpose" rows="3" required></textarea>

    <button type="submit">Schedule Appointment</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
