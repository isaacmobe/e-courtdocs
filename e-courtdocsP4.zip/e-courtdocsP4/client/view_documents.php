<?php
// client/view_documents.php

require_once __DIR__ . '/../includes/header.php';

// Check if caseID is provided
if (!isset($_GET['caseID']) || empty($_GET['caseID'])) {
    echo "<p>Error: No case specified.</p>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$caseID = $_GET['caseID'];

// Retrieve documents for the given caseID from the database
$stmt = $pdo->prepare("SELECT * FROM Documents WHERE caseID = :caseID");
$stmt->execute([':caseID' => $caseID]);
$documents = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Documents for Case <?php echo htmlspecialchars($caseID); ?></h2>

<?php if (count($documents) > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Title</th>
                <th>Type</th>
                <th>Uploaded On</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($documents as $doc): ?>
            <tr>
                <td><?php echo htmlspecialchars($doc['title']); ?></td>
                <td><?php echo htmlspecialchars($doc['type']); ?></td>
                <td><?php echo htmlspecialchars($doc['upload_date']); ?></td>
                <td>
                    <!-- Adjust the path to match where your uploaded files are stored -->
                    <a href="/e-courtdocsP4/uploads/<?php echo urlencode($doc['title']); ?>" download>Download</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No documents found for this case.</p>
<?php endif; ?>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
