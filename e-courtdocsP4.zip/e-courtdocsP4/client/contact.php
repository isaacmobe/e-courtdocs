<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Client') {
    redirectToDashboard(getUserRole());
}

$message = "";

// Handle contact form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipient = $_POST['recipient']; // 'Admin' or 'Lawyer'
    $subject   = $_POST['subject'];
    $body      = $_POST['body'];

    // For demonstration, let's assume admin userID = 1
    // For lawyer, you might want to let the client pick a specific lawyer ID or something else
    if ($recipient === 'Admin') {
        $recipientID = 1; 
    } else {
        // If you want the client to pick a lawyer from a dropdown, handle it similarly
        // For now, we just pick the first lawyer userID
        $stmt = $pdo->query("SELECT userID FROM Users WHERE role='Lawyer' LIMIT 1");
        $lawyerRow = $stmt->fetch(PDO::FETCH_ASSOC);
        $recipientID = $lawyerRow ? $lawyerRow['userID'] : 1; // fallback to admin
    }

    // Create a notification as a contact message
    createNotification($pdo, $recipientID, null, "Subject: $subject | Message: $body", "Contact");

    $message = "Message sent successfully!";
}
?>

<h2>Contact</h2>
<p><?php echo $message; ?></p>

<form method="POST" action="">
    <label for="recipient">Send To</label>
    <select name="recipient" id="recipient" required>
        <option value="Admin">Admin</option>
        <option value="Lawyer">Lawyer</option>
    </select>

    <label for="subject">Subject</label>
    <input type="text" name="subject" id="subject" required>

    <label for="body">Message</label>
    <textarea name="body" id="body" rows="5" required></textarea>

    <button type="submit">Send Message</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
