<?php
require_once __DIR__ . '/../includes/header.php';

// Only clients can access
if (getUserRole() !== 'Client') {
    redirectToDashboard(getUserRole());
}

$clientID = $_SESSION['userID'];
$message  = "";

// Handle case deletion (must belong to this client)
if (isset($_GET['delete_case'])) {
    $caseID = (int)$_GET['delete_case'];

    // Verify this case belongs to the logged‑in client
    $verify = $pdo->prepare("SELECT 1 FROM Cases WHERE caseID = :caseID AND clientID = :clientID");
    $verify->execute([
        ':caseID'   => $caseID,
        ':clientID' => $clientID
    ]);

    if ($verify->fetch()) {
        // Delete the case
        $delStmt = $pdo->prepare("DELETE FROM Cases WHERE caseID = :caseID");
        $delStmt->execute([':caseID' => $caseID]);

        // Notify admin (userID=1) and the assigned lawyer
        createNotification($pdo, 1, $caseID, "Client deleted case #{$caseID}.", "Case Deleted");
        // You could also fetch assigned_to before deletion and notify that lawyer

        $message = "Case #{$caseID} has been deleted.";
    } else {
        $message = "You do not have permission to delete this case.";
    }
}

// Fetch only this client’s cases
$stmt = $pdo->prepare("
    SELECT * 
    FROM Cases 
    WHERE clientID = :clientID
    ORDER BY last_updated DESC
");
$stmt->execute([':clientID' => $clientID]);
$cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Client Dashboard</h2>

<?php if ($message): ?>
    <p style="color:<?php echo strpos($message, 'deleted') ? 'red' : 'green'; ?>">
        <?php echo htmlspecialchars($message); ?>
    </p>
<?php endif; ?>

<!-- Link to create a new case -->
<p><a href="new_case.php">+ Create New Case</a></p>

<h3>Your Cases</h3>
<?php if (count($cases) === 0): ?>
    <p>You have no cases yet. <a href="new_case.php">Submit one now</a>.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Case Number</th>
                <th>Title</th>
                <th>Status</th>
                <th>Last Updated</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($cases as $case): ?>
            <tr>
                <td><?php echo htmlspecialchars($case['case_number']); ?></td>
                <td><?php echo htmlspecialchars($case['title']); ?></td>
                <td><?php echo htmlspecialchars($case['status']); ?></td>
                <td><?php echo htmlspecialchars($case['last_updated']); ?></td>
                <td>
                    <a href="edit_case.php?caseID=<?php echo $case['caseID']; ?>">Edit</a> |
                    <a href="view_documents.php?caseID=<?php echo $case['caseID']; ?>">Documents</a> |
                    <a href="?delete_case=<?php echo $case['caseID']; ?>"
                       onclick="return confirm('Are you sure you want to delete case #<?php echo $case['caseID']; ?>?');">
                       Delete
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<br>
<!-- Links to other sections -->
<p>
    <a href="appointments.php">Appointments</a> |
    <a href="contact.php">Contact</a> |
    <a href="notifications.php">Notifications</a>
</p>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
