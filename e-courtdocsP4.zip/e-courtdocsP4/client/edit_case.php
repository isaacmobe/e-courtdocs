<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Client') {
    redirectToDashboard(getUserRole());
}

$message = "";
$caseID = isset($_GET['caseID']) ? $_GET['caseID'] : null;

// Fetch the case details
$caseStmt = $pdo->prepare("SELECT * FROM Cases WHERE caseID = :cid");
$caseStmt->execute([':cid' => $caseID]);
$case = $caseStmt->fetch(PDO::FETCH_ASSOC);

if (!$case) {
    echo "Case not found.";
    exit;
}

// Update case details if POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title      = $_POST['title'];
    $status     = $case['status']; // status remains or is updated by lawyer
    $lastUpdated= date('Y-m-d H:i:s');

    // Update the case in DB
    $updStmt = $pdo->prepare("UPDATE Cases SET title = :title, last_updated = :lupdated 
                              WHERE caseID = :cid");
    $updStmt->execute([
        ':title'    => $title,
        ':lupdated' => $lastUpdated,
        ':cid'      => $caseID
    ]);

    // Optional: upload additional documents
    if (!empty($_FILES['case_document']['name'])) {
        $docTitle = $_FILES['case_document']['name'];
        $docType  = pathinfo($docTitle, PATHINFO_EXTENSION);
        $docStatus= 'Submitted';
        $uploadDate = date('Y-m-d H:i:s');

        $targetDir = __DIR__ . "/../uploads/";
        if(!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $targetFile = $targetDir . basename($docTitle);
        move_uploaded_file($_FILES['case_document']['tmp_name'], $targetFile);

        $docStmt = $pdo->prepare("INSERT INTO Documents
            (caseID, uploaderID, title, type, status, upload_date)
            VALUES (:caseID, :uploaderID, :title, :type, :status, :udate)");
        $docStmt->execute([
            ':caseID'     => $caseID,
            ':uploaderID' => $_SESSION['userID'],
            ':title'      => $docTitle,
            ':type'       => $docType,
            ':status'     => $docStatus,
            ':udate'      => $uploadDate
        ]);
    }

    // Notify the assigned lawyer that case details were edited
    $lawyerID = $case['assigned_to'];
    createNotification($pdo, $lawyerID, $caseID, "Client updated case #$caseID details.", "Case Updated");

    $message = "Case updated successfully!";
    // Refresh the $case data
    $caseStmt->execute([':cid' => $caseID]);
    $case = $caseStmt->fetch(PDO::FETCH_ASSOC);
}
?>

<h2>Edit Case #<?php echo $case['case_number']; ?></h2>
<p><?php echo $message; ?></p>

<form method="POST" action="" enctype="multipart/form-data">
    <label for="title">Case Title/Description</label>
    <input type="text" name="title" id="title" value="<?php echo $case['title']; ?>" required>

    <p>Current Lawyer: 
        <?php 
        $lawyerName = getUserName($pdo, $case['assigned_to']);
        echo $lawyerName;
        ?>
    </p>

    <label for="case_document">Upload Additional Document (Optional)</label>
    <input type="file" name="case_document" id="case_document">

    <button type="submit">Update Case</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
