<?php
// includes/footer.php
?>
</div> <!-- End .container -->
<script src="../public/js/script.js"></script>
</body>
</html>
