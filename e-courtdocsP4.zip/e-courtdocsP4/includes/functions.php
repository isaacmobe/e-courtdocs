<?php
// includes/functions.php
// Common functions used across the system.

function isLoggedIn() {
    return isset($_SESSION['userID']);
}

function getUserRole() {
    return isset($_SESSION['role']) ? $_SESSION['role'] : null;
}

// Simple function to redirect users to their respective dashboards after login
function redirectToDashboard($role) {
    switch ($role) {
        case 'Admin':
            header("Location: /e-courtdocsP4/admin/dashboard.php");
            break;
        case 'Lawyer':
            header("Location: /e-courtdocsP4/lawyer/dashboard.php");
            break;
        case 'Client':
            header("Location: /e-courtdocsP4/client/dashboard.php");
            break;
        default:
            header("Location: /e-courtdocsP4/login.php");
    }
    exit;
}


// Insert a new notification into the database
function createNotification($pdo, $userID, $caseID, $message, $type) {
    $sql = "INSERT INTO Notifications (userID, caseID, message, type, is_read) 
            VALUES (:userID, :caseID, :message, :type, 0)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':userID' => $userID,
        ':caseID' => $caseID,
        ':message' => $message,
        ':type'    => $type
    ]);
}

// Retrieve notifications for a specific user
function getNotifications($pdo, $userID) {
    $sql = "SELECT * FROM Notifications WHERE userID = :userID ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':userID' => $userID]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Mark a notification as read
function markNotificationAsRead($pdo, $notificationID) {
    $sql = "UPDATE Notifications SET is_read = 1 WHERE notificationID = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $notificationID]);
}

// Simple function to fetch a user's name by ID
function getUserName($pdo, $userID) {
    $sql = "SELECT name FROM Users WHERE userID = :userID";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':userID' => $userID]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['name'] : 'Unknown User';
}
?>
