<?php
// Check if a session is already active; if not, start one.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';

// If user is not logged in and not on login/register/index pages, redirect them
$currentFile = basename($_SERVER['PHP_SELF']);
if (!isLoggedIn() && !in_array($currentFile, ['login.php', 'register.php', 'index.php'])) {
    header('Location: /e-courtdocsP4/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>E-CourtDocs System</title>
    <!-- Using an absolute path ensures that the stylesheet is loaded correctly from any page -->
    <link rel="stylesheet" href="/e-courtdocsP4/public/css/style.css">
    <!-- Website system favicon -->
    <link rel="shortcut icon" href="/public/img/ecdfavicon.png" type="image/x-icon">
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar">
    <div class="navbar-brand">
        <a href="/e-courtdocsP4/index.php">E-CourtDocs</a>
    </div>
    <ul class="navbar-menu">
        <?php if (isLoggedIn()): ?>
            <?php if (getUserRole() === 'Admin'): ?>
                <li><a href="/e-courtdocsP4/admin/dashboard.php">Admin Dashboard</a></li>
            <?php elseif (getUserRole() === 'Lawyer'): ?>
                <li><a href="/e-courtdocsP4/lawyer/dashboard.php">Lawyer Dashboard</a></li>
            <?php elseif (getUserRole() === 'Client'): ?>
                <li><a href="/e-courtdocsP4/client/dashboard.php">Client Dashboard</a></li>
            <?php endif; ?>
            <li><a href="/e-courtdocsP4/logout.php">Logout</a></li>
        <?php else: ?>
            <li><a href="/e-courtdocsP4/login.php">Login</a></li>
            <li><a href="/e-courtdocsP4/register.php">Register</a></li>
        <?php endif; ?>
    </ul>

    <?php if (isLoggedIn()): ?>
        <!-- Notification Icon -->
        <div class="notification-icon">
            <a href="<?php
                $role = getUserRole();
                if ($role === 'Admin') echo '/e-courtdocsP4/admin/notifications.php';
                if ($role === 'Lawyer') echo '/e-courtdocsP4/lawyer/notifications.php';
                if ($role === 'Client') echo '/e-courtdocsP4/client/notifications.php';
            ?>">
                <img src="/e-courtdocsP4/public/img/bell.png" alt="Notifications" width="24" />
            </a>
        </div>
    <?php endif; ?>
</nav>

<!-- Main Container -->
<div class="container">
