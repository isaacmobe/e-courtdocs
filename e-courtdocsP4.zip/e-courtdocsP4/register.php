<?php
// register.php

// Clear any existing session so we don't auto-redirect (optional)
if (session_status() === PHP_SESSION_ACTIVE) {
    session_unset();
    session_destroy();
}
session_start();

require_once __DIR__ . '/includes/header.php';

// If user is already logged in, redirect to their dashboard.
if (isLoggedIn()) {
    redirectToDashboard($_SESSION['role']);
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $role     = trim($_POST['role']);
    $password = $_POST['password'];

    // Hash the password using password_hash() for secure storage.
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert new user into the database.
    try {
        $stmt = $pdo->prepare("INSERT INTO Users (name, email, role, password, created_at) 
                               VALUES (:name, :email, :role, :pass, NOW())");
        $stmt->execute([
            ':name'  => $name,
            ':email' => $email,
            ':role'  => $role,
            ':pass'  => $hashedPassword
        ]);
        // Redirect to the login page after successful registration.
        header("Location: login.php?registered=1");
        exit;
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}
?>

<div class="form-container">
    <h2>Register</h2>
    <p><?php echo $message; ?></p>

    <form method="POST" action="">
        <label for="name">Full Name</label>
        <input type="text" name="name" id="name" required>

        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" required>

        <label for="role">Role</label>
        <select name="role" id="role" required>
            <option value="Client">Client</option>
            <option value="Lawyer">Lawyer</option>
            <!-- Admin is typically not self-registered -->
        </select>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <button type="submit">Register</button>
    </form>

    <div class="form-footer">
        <a href="login.php">Already have an account? Login here</a>
    </div>
</div>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
