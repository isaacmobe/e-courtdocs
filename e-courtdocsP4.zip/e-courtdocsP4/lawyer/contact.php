<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Lawyer') {
    redirectToDashboard(getUserRole());
}

$message = "";

// Similar to client contact logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipient = $_POST['recipient']; // 'Admin' or 'Client'
    $subject   = $_POST['subject'];
    $body      = $_POST['body'];

    if ($recipient === 'Admin') {
        $recipientID = 1; // admin userID
    } else {
        // For demonstration, pick the first client userID or let the lawyer input
        $stmt = $pdo->query("SELECT userID FROM Users WHERE role='Client' LIMIT 1");
        $clientRow = $stmt->fetch(PDO::FETCH_ASSOC);
        $recipientID = $clientRow ? $clientRow['userID'] : 1;
    }

    createNotification($pdo, $recipientID, null, "Subject: $subject | Message: $body", "Contact");
    $message = "Message sent successfully!";
}
?>

<h2>Contact</h2>
<p><?php echo $message; ?></p>

<form method="POST" action="">
    <label for="recipient">Send To</label>
    <select name="recipient" id="recipient" required>
        <option value="Admin">Admin</option>
        <option value="Client">Client</option>
    </select>

    <label for="subject">Subject</label>
    <input type="text" name="subject" id="subject" required>

    <label for="body">Message</label>
    <textarea name="body" id="body" rows="5" required></textarea>

    <button type="submit">Send Message</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
