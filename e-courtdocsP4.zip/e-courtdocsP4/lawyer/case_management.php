<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Lawyer') {
    redirectToDashboard(getUserRole());
}

$caseID = isset($_GET['caseID']) ? $_GET['caseID'] : null;
if (!$caseID) {
    echo "No case selected.";
    exit;
}

// Fetch case details
$caseStmt = $pdo->prepare("SELECT * FROM Cases WHERE caseID = :cid");
$caseStmt->execute([':cid' => $caseID]);
$case = $caseStmt->fetch(PDO::FETCH_ASSOC);

if (!$case) {
    echo "Case not found.";
    exit;
}

// Update case status or add comment
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if updating status
    if (isset($_POST['update_status'])) {
        $newStatus = $_POST['status'];
        $updStmt = $pdo->prepare("UPDATE Cases SET status = :status, last_updated = NOW() WHERE caseID = :cid");
        $updStmt->execute([':status' => $newStatus, ':cid' => $caseID]);

        // Notify client
        // In real scenario, you'd have a direct link to the client ID for this case
        // For demonstration, let's notify all clients or skip if unknown
        // createNotification($pdo, $clientID, $caseID, "Your case #$caseID has been updated to $newStatus.", "Case Update");

        $message = "Case status updated successfully!";
        // Refresh the case data
        $caseStmt->execute([':cid' => $caseID]);
        $case = $caseStmt->fetch(PDO::FETCH_ASSOC);
    }

    // Check if uploading a document for the client
    if (isset($_FILES['lawyer_document']) && !empty($_FILES['lawyer_document']['name'])) {
        $docTitle = $_FILES['lawyer_document']['name'];
        $docType  = pathinfo($docTitle, PATHINFO_EXTENSION);
        $docStatus= 'Review';
        $uploadDate = date('Y-m-d H:i:s');

        $targetDir = __DIR__ . "/../uploads/";
        if(!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $targetFile = $targetDir . basename($docTitle);
        move_uploaded_file($_FILES['lawyer_document']['tmp_name'], $targetFile);

        $docStmt = $pdo->prepare("INSERT INTO Documents
            (caseID, uploaderID, title, type, status, upload_date)
            VALUES (:caseID, :uploaderID, :title, :type, :status, :udate)");
        $docStmt->execute([
            ':caseID'     => $caseID,
            ':uploaderID' => $_SESSION['userID'],
            ':title'      => $docTitle,
            ':type'       => $docType,
            ':status'     => $docStatus,
            ':udate'      => $uploadDate
        ]);

        // Notify the client
        // createNotification($pdo, $clientID, $caseID, "A new document was uploaded by your lawyer.", "Document");
        $message = "Document uploaded successfully!";
    }

    // Check if leaving a comment
    if (isset($_POST['comment']) && !empty($_POST['comment'])) {
        $comment = $_POST['comment'];
        // For simplicity, store as a notification to the client
        // createNotification($pdo, $clientID, $caseID, $comment, "Lawyer Comment");
        $message = "Comment sent to client!";
    }
}

// Fetch documents related to this case
$docStmt = $pdo->prepare("SELECT * FROM Documents WHERE caseID = :cid");
$docStmt->execute([':cid' => $caseID]);
$documents = $docStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Manage Case #<?php echo $case['case_number']; ?></h2>
<p><?php echo $message; ?></p>

<p><strong>Title:</strong> <?php echo $case['title']; ?></p>
<p><strong>Status:</strong> <?php echo $case['status']; ?></p>

<!-- Update case status -->
<form method="POST" action="">
    <label for="status">Update Case Status</label>
    <select name="status" id="status">
        <option value="Filed" <?php if($case['status'] === 'Filed') echo 'selected'; ?>>Filed</option>
        <option value="Reviewed" <?php if($case['status'] === 'Reviewed') echo 'selected'; ?>>Reviewed</option>
        <option value="Submitted" <?php if($case['status'] === 'Submitted') echo 'selected'; ?>>Submitted</option>
        <option value="Approved" <?php if($case['status'] === 'Approved') echo 'selected'; ?>>Approved</option>
    </select>
    <button type="submit" name="update_status">Update Status</button>
</form>

<!-- Documents for this case -->
<h3>Case Documents</h3>
<table>
    <tr>
        <th>Title</th>
        <th>Type</th>
        <th>Upload Date</th>
        <th>Actions</th>
    </tr>
    <?php foreach($documents as $doc): ?>
    <tr>
        <td><?php echo $doc['title']; ?></td>
        <td><?php echo $doc['type']; ?></td>
        <td><?php echo $doc['upload_date']; ?></td>
        <td>
            <!-- Download link (assuming files stored in /uploads/) -->
            <a href="../uploads/<?php echo $doc['title']; ?>" download>Download</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<!-- Upload a document for the client -->
<h3>Upload Document for Client</h3>
<form method="POST" action="" enctype="multipart/form-data">
    <input type="file" name="lawyer_document">
    <button type="submit">Upload</button>
</form>

<!-- Leave a comment for the client -->
<h3>Leave a Comment</h3>
<form method="POST" action="">
    <textarea name="comment" rows="3" placeholder="Type your comment..."></textarea>
    <button type="submit">Send Comment</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
