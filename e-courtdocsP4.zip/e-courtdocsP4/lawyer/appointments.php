<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Lawyer') {
    redirectToDashboard(getUserRole());
}

$message = "";

// Fetch appointments for this lawyer
$lawyerID = $_SESSION['userID'];
$aptStmt = $pdo->prepare("SELECT Appointments.*, Cases.case_number, Users.name as clientName
                          FROM Appointments
                          JOIN Cases ON Appointments.caseID = Cases.caseID
                          JOIN Users ON Appointments.userID = Users.userID
                          WHERE Cases.assigned_to = :lid
                          ORDER BY date_time DESC");
$aptStmt->execute([':lid' => $lawyerID]);
$appointments = $aptStmt->fetchAll(PDO::FETCH_ASSOC);

// Handle new appointment creation if desired
// (similar to client flow, if you want to allow lawyer to schedule appointments for the client)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $caseID   = $_POST['caseID'];
    $dateTime = $_POST['date_time'];
    $purpose  = $_POST['purpose'];
    $status   = 'Scheduled';
    // We'll assign it to the client's userID. For demonstration, assume userID is known or you can pick from a dropdown.
    // This is simplified.

    // Insert new appointment
    $insApt = $pdo->prepare("INSERT INTO Appointments (caseID, userID, date_time, purpose, status)
                             VALUES (:cid, :uid, :dt, :purp, :stat)");
    // Find the client userID from the case or from a form field
    $clientIDStmt = $pdo->prepare("SELECT userID FROM Appointments WHERE caseID = :cid LIMIT 1");
    $clientIDStmt->execute([':cid' => $caseID]);
    $clientRow = $clientIDStmt->fetch(PDO::FETCH_ASSOC);
    $clientID = $clientRow ? $clientRow['userID'] : null;

    $insApt->execute([
        ':cid'  => $caseID,
        ':uid'  => $clientID,
        ':dt'   => $dateTime,
        ':purp' => $purpose,
        ':stat' => $status
    ]);

    // Notify client
    if ($clientID) {
        createNotification($pdo, $clientID, $caseID, "A new appointment has been scheduled by your lawyer.", "Appointment");
    }

    $message = "New appointment scheduled!";
    header("Location: appointments.php");
    exit;
}
?>

<h2>Lawyer Appointments</h2>
<p><?php echo $message; ?></p>

<table>
    <tr>
        <th>Case #</th>
        <th>Client Name</th>
        <th>Date & Time</th>
        <th>Purpose</th>
        <th>Status</th>
    </tr>
    <?php foreach($appointments as $apt): ?>
    <tr>
        <td><?php echo $apt['case_number']; ?></td>
        <td><?php echo $apt['clientName']; ?></td>
        <td><?php echo $apt['date_time']; ?></td>
        <td><?php echo $apt['purpose']; ?></td>
        <td><?php echo $apt['status']; ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<!-- Example form to schedule an appointment for a client -->
<h3>Schedule an Appointment for a Client</h3>
<form method="POST" action="">
    <label for="caseID">Case ID</label>
    <input type="number" name="caseID" id="caseID" required>

    <label for="date_time">Date & Time</label>
    <input type="datetime-local" name="date_time" id="date_time" required>

    <label for="purpose">Purpose</label>
    <textarea name="purpose" id="purpose" rows="3" required></textarea>

    <button type="submit">Schedule</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
