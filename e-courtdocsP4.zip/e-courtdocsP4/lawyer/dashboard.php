<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Lawyer') {
    redirectToDashboard(getUserRole());
}

// Fetch cases assigned to this lawyer
$lawyerID = $_SESSION['userID'];
$stmt = $pdo->prepare("SELECT * FROM Cases WHERE assigned_to = :lid ORDER BY last_updated DESC");
$stmt->execute([':lid' => $lawyerID]);
$cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Lawyer Dashboard</h2>

<!-- List of assigned cases -->
<h3>Cases Assigned to You</h3>
<table>
    <tr>
        <th>Case Number</th>
        <th>Title</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php foreach($cases as $case): ?>
    <tr>
        <td><?php echo $case['case_number']; ?></td>
        <td><?php echo $case['title']; ?></td>
        <td><?php echo $case['status']; ?></td>
        <td>
            <a href="case_management.php?caseID=<?php echo $case['caseID']; ?>">Manage</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<br>
<a href="appointments.php">Appointments</a> | 
<a href="contact.php">Contact</a> | 
<a href="notifications.php">Notifications</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
