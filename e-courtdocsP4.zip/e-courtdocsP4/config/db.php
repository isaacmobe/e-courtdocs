<?php
// config/db.php
// This file handles the database connection for the entire system.

$host = 'localhost';
$db   = 'ecourt1';
$user = 'root';
$pass = ''; // Adjust according to your environment

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    // Set Error Mode to Exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}
?>
