<?php
// login.php
require_once __DIR__ . '/includes/header.php';

if (isLoggedIn()) {
    redirectToDashboard($_SESSION['role']);
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    // Retrieve user data from the database by email.
    $stmt = $pdo->prepare("SELECT * FROM Users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Use password_verify() for comparing the entered password with the stored hash.
    if ($user && password_verify($password, $user['password'])) {
        // Credentials are valid; set session variables.
        $_SESSION['userID'] = $user['userID'];
        $_SESSION['role']   = $user['role'];
        $_SESSION['name']   = $user['name'];

        // Update last_login timestamp.
        $updateStmt = $pdo->prepare("UPDATE Users SET last_login = NOW() WHERE userID = :id");
        $updateStmt->execute([':id' => $user['userID']]);

        // Redirect to the appropriate dashboard.
        redirectToDashboard($user['role']);
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<div class="form-container">
    <h2>Login</h2>
    <p style="color:red;"><?php echo $error; ?></p>

    <form method="POST" action="">
        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <button type="submit">Login</button>
    </form>

    <div class="form-footer">
        <a href="register.php">Don't have an account? Register here</a>
    </div>
</div>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
