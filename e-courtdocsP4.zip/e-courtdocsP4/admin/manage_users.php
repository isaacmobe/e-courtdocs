<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Admin') {
    redirectToDashboard(getUserRole());
}

// Handle user deletion
if (isset($_GET['delete_user'])) {
    $deleteUserID = $_GET['delete_user'];
    $delStmt = $pdo->prepare("DELETE FROM Users WHERE userID = :uid");
    $delStmt->execute([':uid' => $deleteUserID]);
}

// Fetch all users
$usersStmt = $pdo->query("SELECT * FROM Users ORDER BY userID DESC");
$users = $usersStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Manage Users</h2>

<table>
    <tr>
        <th>User ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Role</th>
        <th>Last Login</th>
        <th>Actions</th>
    </tr>
    <?php foreach($users as $u): ?>
    <tr>
        <td><?php echo $u['userID']; ?></td>
        <td><?php echo $u['name']; ?></td>
        <td><?php echo $u['email']; ?></td>
        <td><?php echo $u['role']; ?></td>
        <td><?php echo $u['last_login']; ?></td>
        <td>
            <!-- Delete user link -->
            <a href="?delete_user=<?php echo $u['userID']; ?>"
               onclick="return confirm('Are you sure?');">Delete</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
