<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Admin') {
    redirectToDashboard(getUserRole());
}

// Simple analytics example
// Count total users
$userCountStmt = $pdo->query("SELECT COUNT(*) as total FROM Users");
$userCount = $userCountStmt->fetch(PDO::FETCH_ASSOC)['total'];

// Count total cases
$caseCountStmt = $pdo->query("SELECT COUNT(*) as total FROM Cases");
$caseCount = $caseCountStmt->fetch(PDO::FETCH_ASSOC)['total'];

// Count total notifications
$notifCountStmt = $pdo->query("SELECT COUNT(*) as total FROM Notifications");
$notifCount = $notifCountStmt->fetch(PDO::FETCH_ASSOC)['total'];
?>

<h2>Admin Dashboard</h2>

<h3>System Analytics</h3>
<p>Total Users: <?php echo $userCount; ?></p>
<p>Total Cases: <?php echo $caseCount; ?></p>
<p>Total Notifications: <?php echo $notifCount; ?></p>

<br>
<a href="manage_users.php">Manage Users</a> | 
<a href="manage_files.php">Manage Files</a> | 
<a href="notifications.php">Notifications</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
