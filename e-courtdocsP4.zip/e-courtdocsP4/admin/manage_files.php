<?php
require_once __DIR__ . '/../includes/header.php';

if (getUserRole() !== 'Admin') {
    redirectToDashboard(getUserRole());
}

// Fetch all documents
$docsStmt = $pdo->query("SELECT Documents.*, Cases.case_number, Users.name as uploaderName
                         FROM Documents
                         LEFT JOIN Cases ON Documents.caseID = Cases.caseID
                         LEFT JOIN Users ON Documents.uploaderID = Users.userID
                         ORDER BY upload_date DESC");
$documents = $docsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Manage Files</h2>

<table>
    <tr>
        <th>Document ID</th>
        <th>Case #</th>
        <th>Uploader</th>
        <th>Title</th>
        <th>Type</th>
        <th>Upload Date</th>
        <th>Actions</th>
    </tr>
    <?php foreach($documents as $doc): ?>
    <tr>
        <td><?php echo $doc['documentID']; ?></td>
        <td><?php echo $doc['case_number']; ?></td>
        <td><?php echo $doc['uploaderName']; ?></td>
        <td><?php echo $doc['title']; ?></td>
        <td><?php echo $doc['type']; ?></td>
        <td><?php echo $doc['upload_date']; ?></td>
        <td>
            <a href="../uploads/<?php echo $doc['title']; ?>" download>Download</a>
            <!-- Admin could also delete the file or remove from DB if needed -->
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<a href="dashboard.php">Back to Dashboard</a>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
