// public/js/script.js

// (Optional) You can add any interactivity or notification toggling here.
// For example, toggling a dropdown of notifications, etc.

console.log("E-CourtDocs JavaScript Loaded.");
