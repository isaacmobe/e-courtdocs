-- 1. Create the database
CREATE DATABASE IF NOT EXISTS ecourt1;
USE ecourt1;

-- 2. Create Users table
CREATE TABLE IF NOT EXISTS Users (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME
);

-- 3. Create Cases table
CREATE TABLE IF NOT EXISTS Cases (
    caseID INT AUTO_INCREMENT PRIMARY KEY,
    case_number VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    status VARCHAR(50) NOT NULL,
    assigned_to INT,
    filing_date DATETIME NOT NULL,
    last_updated DATETIME NOT NULL,
    FOREIGN KEY (assigned_to) REFERENCES Users(userID) ON DELETE SET NULL
);

-- 4. Create Documents table
CREATE TABLE IF NOT EXISTS Documents (
    documentID INT AUTO_INCREMENT PRIMARY KEY,
    caseID INT,
    uploaderID INT,
    title VARCHAR(200) NOT NULL,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    upload_date DATETIME NOT NULL,
    FOREIGN KEY (caseID) REFERENCES Cases(caseID) ON DELETE CASCADE,
    FOREIGN KEY (uploaderID) REFERENCES Users(userID) ON DELETE CASCADE
);

-- 5. Create Appointments table
CREATE TABLE IF NOT EXISTS Appointments (
    appointmentID INT AUTO_INCREMENT PRIMARY KEY,
    caseID INT,
    userID INT,
    date_time DATETIME NOT NULL,
    purpose VARCHAR(200) NOT NULL,
    status VARCHAR(50) NOT NULL,
    FOREIGN KEY (caseID) REFERENCES Cases(caseID) ON DELETE CASCADE,
    FOREIGN KEY (userID) REFERENCES Users(userID) ON DELETE CASCADE
);

-- 6. Create Notifications table
CREATE TABLE IF NOT EXISTS Notifications (
    notificationID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT,
    caseID INT,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES Users(userID) ON DELETE CASCADE,
    FOREIGN KEY (caseID) REFERENCES Cases(caseID) ON DELETE CASCADE
);