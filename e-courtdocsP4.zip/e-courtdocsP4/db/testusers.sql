INSERT INTO Users (name, email, role, password, created_at)
VALUES ('Admin User', 'admin@example.com', 'Admin', MD5('admin123'), NOW());

INSERT INTO Users (name, email, role, password, created_at)
VALUES ('Test Lawyer', 'lawyer@example.com', 'Lawyer', MD5('lawyer123'), NOW());

INSERT INTO Users (name, email, role, password, created_at)
VALUES ('Test Client', 'client@example.com', 'Client', MD5('client123'), NOW());


INSERT INTO Users (name, email, role, password, created_at)
VALUES (
    'Admin User',
    'admin@example.com',
    'Admin',
    '$2y$10$BJzIAhy9IoeeAyxDYVQExutafSLNzzT4YWlcnmvozgs6pARsv5W5m',
    NOW()
);
